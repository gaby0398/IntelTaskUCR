// src/app/tareas/crear-tarea/crear-tarea.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CatalogoService } from '../../catalogo/catalogo.service';
import { TareaService } from '../tarea.service';
import { Output, EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';


type CatalogoItem = { id: number; nombre: string };

@Component({
  selector: 'app-crear-tarea',
  standalone: false,
  templateUrl: './crear-tarea.component.html',
  styleUrls: ['./crear-tarea.component.scss']
})
export class CrearTareaComponent implements OnInit {
  tarea: any = {
    cN_Id_tarea: 0,
    cN_Tarea_origen: null,
    cT_Titulo_tarea: '',
    cT_Descripcion_tarea: '',
    cT_Descripcion_espera: '',
    cN_Id_complejidad: null, // puedes cambiarlo por un select si querés
    cN_Id_estado: null,
    cN_Id_prioridad: null,
    cN_Numero_GIS: '',
    cF_Fecha_asignacion: new Date().toISOString().slice(0, 10),
    cF_Fecha_limite: '',
    cF_Fecha_finalizacion: '',
    cN_Usuario_creador: 1, // este puede ajustarse luego con auth
    cN_Usuario_asignado: null
  };

  usuarios: CatalogoItem[] = [];
  estados: CatalogoItem[] = [];
  prioridades: CatalogoItem[] = [];
  complejidades: CatalogoItem[] = [];
  mostrarSelectorOrigen: boolean = false;
  asignarUsuario: boolean = false;
  tareasDisponibles: { id: number; titulo: string }[] = [];

  constructor(
    private catalogoService: CatalogoService,
    private tareaService: TareaService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

 ngOnInit(): void {
  const idUsuarioActual = 7768;

  this.catalogoService.getUsuariosPorOficina(idUsuarioActual).subscribe((data: any[]) => {
    this.usuarios = data.map(u => ({
      id: u.id,
      nombre: `${u.nombre} - ${u.oficina}`
    }));
  });

  this.catalogoService.getEstados().subscribe((data: CatalogoItem[]) => {
    this.estados = data;
  });

  this.catalogoService.getPrioridades().subscribe((data: CatalogoItem[]) => {
    this.prioridades = data;
  });

  this.catalogoService.getComplejidades().subscribe((data: any[]) => {
    this.complejidades = data.map(c => ({
      id: c.cN_Id_complejidad,
      nombre: c.cT_Nombre
    }));
  });

  this.tareaService.getTareas().subscribe((data: any[]) => {
    this.tareasDisponibles = data.map(t => ({
      id: t.cN_Id_tarea,
      titulo: t.cT_Titulo_tarea
    }));
  });
}

  enviando = false;

crearTarea(): void {
  if (this.enviando) return;
  this.enviando = true;

  this.tarea.cN_Id_prioridad = Number(this.tarea.cN_Id_prioridad);
  this.tarea.cN_Id_complejidad = Number(this.tarea.cN_Id_complejidad);
  this.tarea.cN_Usuario_asignado = this.asignarUsuario && this.tarea.cN_Usuario_asignado
    ? Number(this.tarea.cN_Usuario_asignado)
    : null;
  this.tarea.cN_Tarea_origen = this.mostrarSelectorOrigen
    ? Number(this.tarea.cN_Tarea_origen)
    : null;
  this.tarea.cT_Descripcion_espera = this.tarea.cT_Descripcion_espera || ' ';
  this.tarea.cN_Numero_GIS = this.tarea.cN_Numero_GIS || ' ';
  this.tarea.cF_Fecha_finalizacion = this.tarea.cF_Fecha_finalizacion || this.tarea.cF_Fecha_limite;

  this.tareaService.crearTarea(this.tarea).subscribe({
    next: () => {
      this.tarea = {
        cN_Id_tarea: 0,
        cN_Tarea_origen: null,
        cT_Titulo_tarea: '',
        cT_Descripcion_tarea: '',
        cT_Descripcion_espera: '',
        cN_Id_complejidad: null,
        cN_Id_prioridad: null,
        cN_Numero_GIS: '',
        cF_Fecha_asignacion: new Date().toISOString().slice(0, 10),
        cF_Fecha_limite: '',
        cF_Fecha_finalizacion: '',
        cN_Usuario_creador: 1,
        cN_Usuario_asignado: null
      };
      this.mostrarSelectorOrigen = false;
      this.asignarUsuario = false;
      this.enviando = false;
      // ✅ Aquí se muestra el mensaje
  this.snackBar.open('¡Tarea creada exitosamente!', 'Cerrar', {
    duration: 4000,
    horizontalPosition: 'center',
    verticalPosition: 'bottom'
  });
    },
    error: err => {
      console.error('Error al guardar la tarea', err);
      this.enviando = false;
    }
  });
}



  @Output() cerrar = new EventEmitter<void>();

cerrarModal(): void {
  this.cerrar.emit();
}

}
