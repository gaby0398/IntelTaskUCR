import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { TareaService } from '../tarea.service';
import { ITarea } from '../tarea.model';
import { CatalogoService } from '../../catalogo/catalogo.service';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-cambiar-estado',
  standalone: false,
  templateUrl: './cambiar-estado.component.html',
  styleUrls: ['./cambiar-estado.component.scss']
})
export class CambiarEstadoComponent implements OnInit {
  @Input() tarea!: ITarea;
  @Output() cerrar = new EventEmitter<void>();

  estados: { id: number; nombre: string }[] = [];
  estadoSeleccionado: number | null = null;
  justificacion: string = '';
  enviando = false;
  observaciones: string = '';
  nuevoArchivo: File | null = null; // <- NUEVO

  constructor(
    private tareaService: TareaService,
    private catalogoService: CatalogoService
  ) {}

  ngOnInit(): void {
    this.catalogoService.getEstados().subscribe((data) => {
      this.estados = data;
    });
  }

  requiereJustificacion(id: number | null): boolean {
    return id === 13 || id === 14 || id === 15;
  }

  cambiarEstado(): void {
  if (!this.estadoSeleccionado || this.estadoSeleccionado === this.tarea.cN_Id_estado) return;

  this.enviando = true;
  const estadoAnterior = this.tarea.cN_Id_estado;
  const nuevaTarea = { ...this.tarea, cN_Id_estado: this.estadoSeleccionado };

  // Marcar fecha de finalización si pasa a estado 12
  if (this.estadoSeleccionado === 12) {
    nuevaTarea.cF_Fecha_finalizacion = new Date().toISOString();
  }

  // Guardar justificación en el campo adecuado si es "En espera"
  if (this.estadoSeleccionado === 13) {
    nuevaTarea.cT_Descripcion_espera = this.justificacion;
  }

  // Paso 1: Actualizar tarea
  this.tareaService.actualizarTarea(nuevaTarea.cN_Id_tarea, nuevaTarea).subscribe({
    next: () => {
      // Paso 2: Guardar justificación adicional si es Rechazada o Incumplida
      let justificacionObs: Observable<any> = of(null);

      if (this.estadoSeleccionado === 14) {
        justificacionObs = this.tareaService.guardarJustificacionIncumplimiento({
          cN_Id_tarea: nuevaTarea.cN_Id_tarea,
          ct_Justificacion_incumplimiento: this.justificacion,
          cf_Fecha_incumplimiento: new Date().toISOString()
        });
      } else if (this.estadoSeleccionado === 15) {
        const justificacionData = {
          cN_Id_tarea: nuevaTarea.cN_Id_tarea,
          ct_Descripcion_rechazo: this.justificacion,
          cf_Fecha_hora_rechazo: new Date().toISOString()
        };

        console.log('➡️ Enviando justificación de rechazo:', justificacionData);

        justificacionObs = this.tareaService.guardarJustificacionRechazo(justificacionData);
      }

      // Paso 3: Registrar bitácora
      justificacionObs.subscribe({
        next: () => {
          const cambio = {
            cN_Id_tarea_permiso: nuevaTarea.cN_Id_tarea,
            cN_Id_tipo_documento: 1,
            cN_Id_estado_anterior: estadoAnterior,
            cN_Id_estado_nuevo: this.estadoSeleccionado!,
            cF_Fecha_hora_cambio: new Date().toISOString(),
            cN_Id_usuario_responsable: nuevaTarea.cN_Usuario_asignado ?? null,
            cT_Observaciones: this.justificacion || this.observaciones || 'Sin observaciones'
          };

          this.tareaService.registrarCambioEstado(cambio).subscribe({
            next: () => {
              // Paso 4 (opcional): Subir adjunto si se seleccionó uno
              if (this.nuevoArchivo) {
                const usuarioId = this.tarea.cN_Usuario_asignado ?? 1; // ⚠️ Ajustar al usuario real

                this.tareaService.subirArchivo(this.nuevoArchivo, usuarioId).subscribe({
                  next: (adjuntoCreado) => {
                    const relacion = {
                      cN_Id_adjuntos: adjuntoCreado.cN_Id_adjuntos,
                      cN_Id_tarea: this.tarea.cN_Id_tarea
                    };

                    this.tareaService.vincularAdjuntoATarea(relacion).subscribe({
                      next: () => {
                        this.nuevoArchivo = null;
                        this.enviando = false;
                        this.cerrar.emit();
                      },
                      error: err => {
                        console.error('❌ Error al vincular adjunto:', err);
                        this.enviando = false;
                      }
                    });
                  },
                  error: err => {
                    console.error('❌ Error al subir adjunto:', err);
                    this.enviando = false;
                  }
                });
              } else {
                this.enviando = false;
                this.cerrar.emit(); // No hay adjunto, se cierra igual
              }
            },
            error: () => this.enviando = false
          });
        },
        error: (err) => {
          console.error('❌ Error al guardar justificación:', err);
          this.enviando = false;
        }
      });
    },
    error: () => this.enviando = false
  });
}




// Al seleccionar un archivo
onArchivoSeleccionado(event: any): void {
  this.nuevoArchivo = event.target.files[0];
}

}
