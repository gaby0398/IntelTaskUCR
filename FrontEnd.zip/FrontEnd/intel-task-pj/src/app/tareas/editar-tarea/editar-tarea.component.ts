import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { TareaService } from '../tarea.service';
import { ITarea } from '../tarea.model';
import { CatalogoService } from '../../catalogo/catalogo.service';

@Component({
  selector: 'app-editar-tarea',
  templateUrl: './editar-tarea.component.html',
  standalone: false,
  styleUrls: ['./editar-tarea.component.scss']
})
export class EditarTareaComponent implements OnInit {
  @Input() tarea!: ITarea;
  @Output() cerrar = new EventEmitter<void>();

  tareaEditada: ITarea = {} as ITarea;
  enviando = false;

  prioridades: { id: number, nombre: string }[] = [];
  complejidades: { id: number, nombre: string }[] = [];
  usuarios: { id: number, nombre: string }[] = [];
  tareasDisponibles: { id: number, titulo: string }[] = [];
 

  constructor(
    private tareaService: TareaService,
    private catalogoService: CatalogoService
  ) {}

  ngOnInit(): void {
    this.tareaEditada = { ...this.tarea };

    this.catalogoService.getPrioridades().subscribe(data => {
      this.prioridades = data;
    });

    this.catalogoService.getComplejidades().subscribe(data => {
      this.complejidades = data;
    });

    this.catalogoService.getUsuarios().subscribe(data => {
      this.usuarios = data;
    });

    this.tareaService.getTareas().subscribe(data => {
      console.log('Tareas disponibles:', data);
      this.tareasDisponibles = data.map(t => ({
        id: t.cN_Id_tarea,
        titulo: t.cT_Titulo_tarea
      }));
    });

  this.catalogoService.getComplejidades().subscribe(data => {
    this.complejidades = data.map((c: any) => ({
      id: c.cN_Id_complejidad,
      nombre: c.cT_Nombre
    }));
  });

  }

  actualizarTarea(): void {
    if (this.enviando) return;

    // Si se cambió el usuario asignado, actualizamos la fecha de asignación
    if (this.tarea.cN_Usuario_asignado !== this.tareaEditada.cN_Usuario_asignado) {
      this.tareaEditada.cF_Fecha_asignacion = new Date().toISOString();
    } else {
      this.tareaEditada.cF_Fecha_asignacion = this.tarea.cF_Fecha_asignacion;
    }

    // Fecha de finalización: se mantiene igual a fecha límite a menos que el estado sea "Finalizada" (ID 12)
    if (this.tareaEditada.cN_Id_estado === 12) {
      this.tareaEditada.cF_Fecha_finalizacion = new Date().toISOString();
    } else {
      this.tareaEditada.cF_Fecha_finalizacion = this.tareaEditada.cF_Fecha_limite;
    }

    // Creador se mantiene igual
    this.tareaEditada.cN_Usuario_creador = this.tarea.cN_Usuario_creador;

    this.enviando = true;
    this.tareaService.actualizarTarea(this.tareaEditada.cN_Id_tarea, this.tareaEditada).subscribe({
      next: () => {
        this.enviando = false;
        this.cerrar.emit();
      },
      error: err => {
        console.error('Error al actualizar la tarea', err);
        this.enviando = false;
      }
    });
  }

  cancelarEdicion(): void {
    this.cerrar.emit();
  }


  
}
