import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';  // Asegúrate de que esté importado correctamente
import { ITarea } from './tarea.model';

@Injectable({
  providedIn: 'root'
})
export class TareaService {
  private baseUrl = 'https://localhost:7296/api/Tarea'; 
  private justificacionUrl = 'https://localhost:7296/api/TareaJustificacionRechazo';
  private incumplimientoUrl = 'https://localhost:7296/api/TareaIncumplimiento'; // Ruta para Incumplimiento

  constructor(private http: HttpClient) { }

  // Obtener todas las tareas
  getTareas(): Observable<ITarea[]> {
    return this.http.get<ITarea[]>(this.baseUrl);
  }

  // Crear una nueva tarea
  crearTarea(tarea: any): Observable<any> {
    return this.http.post<any>(this.baseUrl, tarea);
  }

  // Obtener justificaciones por tarea
  getJustificacionesPorTarea(id: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.justificacionUrl}/PorTarea/${id}`);
  }

  // Obtener historial de estado por tarea
  getHistorialEstadoPorTarea(tareaId: number): Observable<any[]> {
    return this.http.get<any[]>(`https://localhost:7296/api/BitacoraCambioEstado/PorTarea/${tareaId}`);
  }

  // Obtener adjuntos por tarea
  getAdjuntosPorTarea(idTarea: number): Observable<any[]> {
    return this.http.get<any[]>(`https://localhost:7296/api/AdjuntoXTarea/tarea/${idTarea}/archivos`);
  }

  // Agregar un adjunto a una tarea
  agregarAdjunto(adjunto: any): Observable<any> {
    return this.http.post<any>('https://localhost:7296/api/Adjunto', adjunto);
  }
/*
  // Vincular un adjunto a una tarea
  vincularAdjuntoATarea(relacion: any): Observable<any> {
    return this.http.post<any>('https://localhost:7296/api/AdjuntoXTarea', relacion);
  }*/

  // Obtener seguimientos de tarea
  getSeguimientosPorTarea(idTarea: number): Observable<any[]> {
    return this.http.get<any[]>(`https://localhost:7296/api/TareaSeguimiento/PorTarea/${idTarea}`);
  }

  // Agregar un seguimiento a una tarea
  agregarSeguimiento(seguimiento: any): Observable<any> {
    return this.http.post<any>('https://localhost:7296/api/TareaSeguimiento', seguimiento);
  }

  // Actualizar una tarea
  actualizarTarea(id: number, tarea: any): Observable<any> {
    return this.http.put<any>(`https://localhost:7296/api/Tarea/${id}`, tarea);
  }

  // Registrar cambio de estado en la bitácora
  registrarCambioEstado(cambio: {
    cN_Id_tarea_permiso: number;
    cN_Id_tipo_documento: number;
    cN_Id_estado_anterior: number;
    cN_Id_estado_nuevo: number;
    cF_Fecha_hora_cambio: string;
    cN_Id_usuario_responsable: number | null;
    cT_Observaciones: string;
  }): Observable<any> {
    // Asegurarse de que el campo cN_Id_estado_nuevo sea un número, no null
    cambio.cN_Id_estado_nuevo = Number(cambio.cN_Id_estado_nuevo);

    return this.http.post<any>('https://localhost:7296/api/BitacoraCambioEstado', cambio);
  }

  // Cambiar el estado de la tarea y registrar la justificación si es necesario
  cambiarEstado(tareaId: number, nuevoEstado: number, justificacion: string | null, usuarioId: number): Observable<any> {
    const nuevaTarea = {
      cN_Id_tarea: tareaId,
      cN_Id_estado: nuevoEstado
    };

    // Actualizamos el estado de la tarea
    return this.http.put(`${this.baseUrl}/Tareas/${tareaId}`, nuevaTarea).pipe(
      switchMap(() => {
        if (nuevoEstado === 14 || nuevoEstado === 7) { // Si es Incumplimiento o Rechazo
          let justificacionData;
          
          if (nuevoEstado === 14) { // Incumplimiento
            justificacionData = {
              cN_Id_tarea: tareaId,
              CT_Justificacion_incumplimiento: justificacion,
              CF_Fecha_incumplimiento: new Date().toISOString()
            };
            return this.http.post(`${this.incumplimientoUrl}`, justificacionData);  // Cambiado a la ruta correcta
          } else if (nuevoEstado === 7) { // Rechazado
            justificacionData = {
              cN_Id_tarea: tareaId,
              CT_Descripcion_rechazo: justificacion,
              CF_Fecha_hora_rechazo: new Date().toISOString()
            };
            return this.http.post(`${this.justificacionUrl}`, justificacionData);  // Ruta correcta para Rechazo
          }
        }
        
        // Si no es Incumplimiento ni Rechazo, registrar solo el cambio de estado en la bitácora
        return this.registrarCambioEstadoEnBitacora(tareaId, nuevoEstado, usuarioId);
      })
    );
  }

  // Registrar el cambio de estado en la bitácora si no es Incumplimiento ni Rechazo
  registrarCambioEstadoEnBitacora(tareaId: number, nuevoEstado: number, usuarioId: number): Observable<any> {
    const cambioEstado = {
      cN_Id_tarea_permiso: tareaId,
      cN_Id_estado_anterior: 1, // Asume que el estado anterior es 1 como ejemplo
      cN_Id_estado_nuevo: nuevoEstado,
      cF_Fecha_hora_cambio: new Date().toISOString(),
      cN_Id_usuario_responsable: usuarioId,
      cT_Observaciones: '' // Dejar vacío si no hay observaciones
    };

    return this.http.post(`${this.baseUrl}/BitacoraCambioEstado`, cambioEstado);
  }


  guardarJustificacionIncumplimiento(data: {
  cN_Id_tarea: number;
  ct_Justificacion_incumplimiento: string;
  cf_Fecha_incumplimiento: string;
}): Observable<any> {
  return this.http.post(`${this.incumplimientoUrl}`, data);
}

guardarJustificacionRechazo(data: {
  cN_Id_tarea: number;
  ct_Descripcion_rechazo: string;
  cf_Fecha_hora_rechazo: string;
}): Observable<any> {
  return this.http.post(`${this.justificacionUrl}`, data);
}




getTareaFiltrada(id: number): Observable<any> {
  return this.http.get<any>(`https://localhost:7296/api/Tarea/filtrada?cN_Id_tarea=${id}`);
}

// Subir archivo real al backend
subirArchivo(archivo: File, usuarioId: number): Observable<any> {
  const formData = new FormData();
  formData.append('archivo', archivo);
  formData.append('usuarioId', usuarioId.toString());

  return this.http.post('https://localhost:7296/api/Adjunto/subir', formData);
}
vincularAdjuntoATarea(data: any): Observable<any> {
  return this.http.post('https://localhost:7296/api/AdjuntoXTarea', data);
}

getIncumplimientosPorTarea(id: number): Observable<any[]> {
  return this.http.get<any[]>(`https://localhost:7296/api/TareaIncumplimiento/PorTarea/${id}`);
}

getJustificacionesRechazoPorTarea(tareaId: number): Observable<any[]> {
  return this.http.get<any[]>(`https://localhost:7296/api/TareaJustificacionRechazo/tarea/${tareaId}`);
}



}
