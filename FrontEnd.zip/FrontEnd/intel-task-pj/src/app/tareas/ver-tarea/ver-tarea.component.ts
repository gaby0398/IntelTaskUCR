import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { ITarea } from '../tarea.model';
import { CatalogoService } from '../../catalogo/catalogo.service';
import { TareaService } from '../tarea.service';

@Component({
  selector: 'app-ver-tarea',
  standalone: false,
  templateUrl: './ver-tarea.component.html',
  styleUrls: ['./ver-tarea.component.scss']
})
export class VerTareaComponent implements OnInit {
  @Input() tarea!: ITarea;
  @Output() cerrar = new EventEmitter<void>();

  usuarios: { id: number, nombre: string }[] = [];
  estados: { id: number, nombre: string }[] = [];
  prioridades: { id: number, nombre: string }[] = [];
  historialEstado: any[] = [];
  adjuntos: any[] = [];
  seguimientos: any[] = [];
  mostrarModalSeguimiento = false;
  nuevoComentario = '';
  incumplimientos: any[] = [];
  justificacionesRechazo: any[] = [];


  nuevoArchivo: File | null = null;

  constructor(
    private catalogoService: CatalogoService,
    private tareaService: TareaService
  ) {}

  ngOnInit(): void {
  this.catalogoService.getUsuarios().subscribe(data => this.usuarios = data);
  this.catalogoService.getEstados().subscribe(data => this.estados = data);
  this.catalogoService.getPrioridades().subscribe(data => this.prioridades = data);

  // Justificaciones de rechazo
  this.tareaService.getJustificacionesRechazoPorTarea(this.tarea.cN_Id_tarea).subscribe(j => {
  this.justificacionesRechazo = j;
});

  // Justificaciones de incumplimiento
  this.tareaService.getIncumplimientosPorTarea(this.tarea.cN_Id_tarea).subscribe(i => {
    this.incumplimientos = i;

    // Historial de estado
    this.tareaService.getHistorialEstadoPorTarea(this.tarea.cN_Id_tarea).subscribe(data => {
      this.historialEstado = data;
    });

    // Adjuntos de la tarea
    this.cargarAdjuntos();
  });

  // Seguimientos
  this.tareaService.getSeguimientosPorTarea(this.tarea.cN_Id_tarea).subscribe(data => {
    this.seguimientos = data;
  });
}


  cerrarModal(): void {
    this.cerrar.emit();
  }

  getNombreUsuario(id?: number): string {
    if (!id) return '—';
    const usuario = this.usuarios.find(u => u.id === id);
    return usuario ? usuario.nombre : '—';
  }

  getNombreEstado(id: number): string {
    const estado = this.estados.find(e => e.id === id);
    return estado ? estado.nombre : 'Desconocido';
  }

  getNombrePrioridad(id: number): string {
    const prioridad = this.prioridades.find(p => p.id === id);
    return prioridad ? prioridad.nombre : 'Desconocido';
  }

  cargarAdjuntos(): void {
    if (this.tarea && this.tarea.cN_Id_tarea) {
      this.tareaService.getAdjuntosPorTarea(this.tarea.cN_Id_tarea).subscribe({
        next: data => this.adjuntos = data,
        error: err => console.error('Error al obtener los adjuntos:', err)
      });
    }
  }

  onArchivoSeleccionado(event: any): void {
    this.nuevoArchivo = event.target.files[0];
  }

  subirAdjunto(): void {
    if (!this.nuevoArchivo || !this.tarea) return;

    const usuarioId = 1; // 🔧 Reemplazar por ID real del usuario

    this.tareaService.subirArchivo(this.nuevoArchivo, usuarioId).subscribe({
      next: adjuntoCreado => {
        const relacion = {
          cN_Id_adjuntos: adjuntoCreado.cN_Id_adjuntos,
          cN_Id_tarea: this.tarea.cN_Id_tarea
        };

        this.tareaService.vincularAdjuntoATarea(relacion).subscribe({
          next: () => {
            this.cargarAdjuntos();
            this.nuevoArchivo = null;
          },
          error: err => console.error('❌ Error al vincular adjunto:', err)
        });
      },
      error: err => console.error('❌ Error al subir archivo real:', err)
    });
  }

  guardarComentario(): void {
    if (!this.nuevoComentario.trim()) return;

    const seguimiento = {
      cN_Id_tarea: this.tarea.cN_Id_tarea,
      cT_Comentario: this.nuevoComentario,
      cF_Fecha_seguimiento: new Date()
    };

    this.tareaService.agregarSeguimiento(seguimiento).subscribe({
      next: () => {
        this.nuevoComentario = '';
        this.mostrarModalSeguimiento = false;
        this.cargarSeguimientos();
      },
      error: err => console.error('Error al guardar el comentario', err)
    });
  }

  cerrarModalComentario(): void {
    this.mostrarModalSeguimiento = false;
    this.nuevoComentario = '';
  }

  cargarSeguimientos(): void {
    this.tareaService.getSeguimientosPorTarea(this.tarea.cN_Id_tarea).subscribe(data => {
      this.seguimientos = data;
    });
  }
}
