import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  standalone: false,
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  correo: string = '';
  contrasenna: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  login() {
    this.authService.login(this.correo, this.contrasenna).subscribe({
      next: () => {
        const rol = localStorage.getItem('rol'); // Obtener el rol del localStorage

        // Verificar el rol y redirigir a la ruta correspondiente
        if (rol === '1' || rol === '2' || rol === '3' || rol === '9') {
          this.router.navigate(['/panel']); // Redirigir al panel si el rol es adecuado
        } else {
          this.router.navigate(['/tareas']); // Redirigir a tareas si el rol no tiene acceso al panel
        }
      },
      error: () => {
        alert('Credenciales incorrectas');
      }
    });
  }
}
