import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  standalone: false,
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  nombre: string = '';
  correo: string = '';
  contrasenna: string = '';
  fechaNacimiento: string = '';
  rol: number = 0;

  constructor(private authService: AuthService, private router: Router,private dialogRef: MatDialogRef<RegisterComponent>) {}



registrar() {
  this.authService.obtenerUsuarios().subscribe({
    next: usuarios => {
      const maxId = Math.max(...usuarios.map(u => u.cN_Id_usuario));
      const nuevoId = maxId + 1;

      const nuevoUsuario = {
        cN_Id_usuario: nuevoId,
        cT_Nombre_usuario: this.nombre,
        cT_Correo_usuario: this.correo,
        cT_Contrasenna: this.contrasenna,
        cF_Fecha_nacimiento: this.fechaNacimiento,
        cB_Estado_usuario: true,
        cF_Fecha_creacion_usuario: new Date(),
        cF_Fecha_modificacion_usuario: new Date(),
        cN_Id_rol: this.rol // Asignar el valor de rol aquí
      };

      this.authService.registrarConId(nuevoUsuario).subscribe({
        next: () => {
          alert('¡Cuenta creada con éxito!');
          this.router.navigate(['/login']);
        },
        error: () => {
          alert('Error al registrar. Intentá de nuevo.');
        }
      });
    },
    error: () => {
      alert('Error al obtener usuarios');
    }
  });
}

cerrarModal(): void {
  this.dialogRef.close(); // ✅ Cierra el modal
}


}
