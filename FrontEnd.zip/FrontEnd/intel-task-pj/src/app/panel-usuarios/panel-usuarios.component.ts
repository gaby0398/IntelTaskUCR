import { Component, OnInit } from '@angular/core';  // Servicio para manejar los usuarios
import { UsuarioService } from '../services/usuario.service';
import { RegisterComponent } from '../auth/register/register.component';
import { MatDialog } from '@angular/material/dialog';  // Importa MatDialog

@Component({
  selector: 'app-panel-usuarios',
  templateUrl: './panel-usuarios.component.html',
  standalone: false,
  styleUrls: ['./panel-usuarios.component.scss']
})
export class PanelUsuariosComponent implements OnInit {

  usuarios: any[] = [];  // Lista de usuarios
  loading: boolean = false;
  displayedColumns: string[] = ['nombre', 'correo','rol', 'estado', 'acciones'];  // Definir las columnas que se mostrarán

  constructor(private usuarioService: UsuarioService, public dialog: MatDialog) { }

  ngOnInit(): void {
    this.getUsuarios();  // Obtener los usuarios al cargar el componente
  }

  // Método para obtener todos los usuarios
  getUsuarios(): void {
    this.loading = true;
    this.usuarioService.getAllUsuarios().subscribe(
      (data) => {
        console.log(data);
        this.usuarios = data;
        this.loading = false;
      },
      (error) => {
        console.error('Error al obtener los usuarios', error);
        this.loading = false;
      }
    );
  }
getRolName(rolId: number): string {
  // Define el mapeo de roles (esto depende de los valores en tu base de datos)
  const roles = {
    1: 'Director',
    2: 'Subdirector',
    3: 'Jefe',
    4: 'Coordinador',
    5: 'Profesional 3',
    6: 'Profesional 2',
    7: 'Profesional 1',
    8: 'Técnico',
    9: 'Administrador'
  };

  // Retornar el nombre del rol correspondiente, o 'Desconocido' si el rol no se encuentra
  return roles[rolId as keyof typeof roles] || 'Desconocido';
}


  // Método para cambiar el estado de un usuario (activar/desactivar)
  cambiarEstado(usuario: any, estado: boolean): void {
    this.usuarioService.cambiarEstadoUsuario(usuario.cN_Id_usuario, estado).subscribe(
      (response) => {
        usuario.cB_Estado_usuario = estado;  // Actualizar el estado en la tabla
        alert('Estado actualizado correctamente');
      },
      (error) => {
        console.error('Error al cambiar el estado', error);
        alert('No se pudo cambiar el estado');
      }
    );
  }

  // Método para crear un nuevo usuario
  crearUsuario(): void {
    // Navegar al formulario de creación de usuario
  }

  // Método para editar un usuario
  editarUsuario(id: number): void {
    // Navegar al formulario de edición de usuario
  }



   // Método para abrir el modal de crear nuevo usuario
 openCreateUserModal(): void {
  const dialogRef = this.dialog.open(RegisterComponent, {
    width: '570px', // o lo que prefieras
     maxWidth: '75vw',
    disableClose: true
  });

  dialogRef.afterClosed().subscribe(result => {
    if (result) {
      this.getUsuarios();
    }
  });
}



}
