import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-notificaciones',
  templateUrl: './notificaciones.component.html',
  standalone: false,
  styleUrls: ['./notificaciones.component.scss']
})
export class NotificacionesComponent implements OnInit {
  notificaciones: any[] = [];

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    const idUsuario = parseInt(localStorage.getItem('idUsuario') || '0');

    if (!idUsuario) {
      alert("No hay sesión activa. Por favor, inicie sesión.");
      this.router.navigate(['/login']);
      return;
    }

    this.http.get(`https://localhost:7296/api/TINotificacionUsuario/usuario/${idUsuario}`)
      .subscribe((data: any) => {
        this.notificaciones = data;
      });
  }

  getTituloTipo(tipo: number): string {
    switch (tipo) {
      case 1: return '📝 Tarea asignada';
      case 2: return '✅ Permiso aprobado';
      case 3: return '⏰ Recordatorio';
      default: return '🔔 Notificación';
    }
  }

  getTipoClase(tipo: number): string {
    switch (tipo) {
      case 1: return 'notificacion tarea';
      case 2: return 'notificacion permiso';
      case 3: return 'notificacion recordatorio';
      default: return 'notificacion generica';
    }
  }

  marcarComoLeida(id: number) {
  const leidas = JSON.parse(localStorage.getItem('notificacionesLeidas') || '[]');
  if (!leidas.includes(id)) {
    leidas.push(id);
    localStorage.setItem('notificacionesLeidas', JSON.stringify(leidas));
  }
}

esLeida(id: number): boolean {
  const leidas = JSON.parse(localStorage.getItem('notificacionesLeidas') || '[]');
  return leidas.includes(id);
}

eliminarBackend(idNotificacion: number) {
  const idUsuario = parseInt(localStorage.getItem('idUsuario') || '0');
  if (!idUsuario) return;

  this.http.delete(`https://localhost:7296/api/TINotificacionUsuario/${idNotificacion}/${idUsuario}`)
    .subscribe(() => {
      this.notificaciones = this.notificaciones.filter(n => n.cN_Id_notificacion !== idNotificacion);
    });
}


}
