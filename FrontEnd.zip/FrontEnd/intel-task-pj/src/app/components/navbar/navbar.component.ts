import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  standalone: false,
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  nombreUsuario: string | null = localStorage.getItem('nombreUsuario');

  constructor(private authService: AuthService, private router: Router) {}

  cerrarSesion() {
    this.authService.cerrarSesion();
  }
}
