import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EstadisticasService {

  private apiUrl = 'https://localhost:7296/api/Usuarios/usuarios-activos';  // Endpoint para obtener usuarios activos
  private apiUrlTareasEnProceso = 'https://localhost:7296/api/Tarea/enProceso';  // Endpoint para obtener tareas en proceso
  private apiUrlPermisosRegistradosCantidad = 'https://localhost:7296/api/Permiso/registrados/cantidad';  // Endpoint para obtener la cantidad de permisos registrados
  private apiUrlTareasProximasAVencerCantidad = 'https://localhost:7296/api/Tarea/proximas-a-vencer/cantidad';  // Endpoint para obtener la cantidad de tareas próximas a vencer
  constructor(private http: HttpClient) { }

  // Obtener todas las estadísticas
  getEstadisticas(): Observable<any> {
    return forkJoin({
      usuariosActivos: this.http.get<any>(this.apiUrl),
      tareasEnProceso: this.http.get<any>(this.apiUrlTareasEnProceso),
      permisosRegistradosCantidad: this.http.get<any>(this.apiUrlPermisosRegistradosCantidad), // Nueva llamada para permisos solicitados
      tareasProximasAVencerCantidad: this.http.get<any>(this.apiUrlTareasProximasAVencerCantidad)  // Nueva llamada para tareas próximas a vencer
    });
  }
}

