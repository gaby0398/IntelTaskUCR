import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  private apiUrl = 'https://localhost:7296/api/Usuarios';  // URL de la API de usuarios

  constructor(private http: HttpClient) { }

  // Obtener todos los usuarios
  getAllUsuarios(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}`);
  }

  cambiarEstadoUsuario(id: number, estado: boolean): Observable<any> {
  const nuevoEstado = estado ? 'activo' : 'inactivo'; // convertir booleano a string

  return this.http.patch(`${this.apiUrl}/${id}/estado`, JSON.stringify(nuevoEstado), {
    headers: {
      'Content-Type': 'application/json'
    }
  });
}




  // Crear un nuevo usuario
  createUsuario(usuario: any): Observable<any> {
    return this.http.post(this.apiUrl, usuario);
  }

  // Editar un usuario
  updateUsuario(id: number, usuario: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, usuario);
  }

  // Eliminar un usuario
  deleteUsuario(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
