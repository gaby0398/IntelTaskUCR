import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators'; // 👈 Importa tap

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'https://localhost:7296/api/Auth';
  private apiUrlUsuarios = 'https://localhost:7296/api/Usuarios';


  constructor(private http: HttpClient, private router: Router) {}

  login(correo: string, contrasenna: string) {
  return this.http.post<any>(`${this.apiUrl}/login`, { correo, contrasenna }).pipe(
    tap(res => {
      if (res?.token) {
        this.guardarToken(res.token);
        localStorage.setItem('rol', res.idRol);               // 👈 Guardamos rol
        localStorage.setItem('nombreUsuario', res.nombreUsuario); // 👈 Guardamos nombre
        localStorage.setItem('idUsuario', res.idUsuario);     // 👈 Guardamos ID
        
       
      
      }
       
    })
  );
}

  guardarToken(token: string) {
    localStorage.setItem('token', token);
  }

  obtenerToken() {
    return localStorage.getItem('token');
  }

  cerrarSesion() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }

  estaAutenticado(): boolean {
    return !!localStorage.getItem('token');
  }

  registrar(nombre: string, correo: string, contrasenna: string, fechaNacimiento: string) {
  const nuevoUsuario = {
    cT_Nombre_usuario: nombre,
    cT_Correo_usuario: correo,
    cT_Contrasenna: contrasenna,
    cF_Fecha_nacimiento: fechaNacimiento,
    cB_Estado_usuario: true,
    cF_Fecha_creacion_usuario: new Date(),
    cF_Fecha_modificacion_usuario: new Date(),
    cN_Id_rol: 2 // rol por defecto
  };

  return this.http.post(`${this.apiUrlUsuarios}`, nuevoUsuario);
}

obtenerUsuarios() {
  return this.http.get<any[]>('https://localhost:7296/api/Usuarios');
}

registrarConId(usuario: any) {
  return this.http.post('https://localhost:7296/api/Usuarios', usuario);
}



  

}
