import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(): boolean {
    const rol = localStorage.getItem('rol');

    // Permitir el acceso solo a roles específicos (por ejemplo, Administrador, Jefe, etc.)
    if (rol === '1' || rol === '2' || rol === '3'|| rol === '9') {  // Roles permitidos (ejemplo: Director, Subdirector, Jefe)
      return true;
    } else {
      alert('Acceso denegado');
      this.router.navigate(['/tareas']);  // Redirigir a tareas si no tiene permiso
      return false;
    }
  }
}
