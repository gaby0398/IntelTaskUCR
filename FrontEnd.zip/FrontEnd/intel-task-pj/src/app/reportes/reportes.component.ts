import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-reportes',
  templateUrl: './reportes.component.html',
  standalone: false,
  styleUrls: ['./reportes.component.scss']
})
export class ReportesComponent implements OnInit {

  filtros = {
    tipo: 'tareas',
    estado: '',
    desde: '',
    hasta: '',
    usuario: ''
  };

  reportes: any[] = [];
  yaConsultado = false;

  estadosDisponibles: { id: number, nombre: string }[] = [];
  usuariosDisponibles: { id: number, nombre: string }[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.cargarEstados();
    this.cargarUsuarios();
  }

  // Cargar usuarios del sistema
  cargarUsuarios(): void {
    this.http.get<any[]>('https://localhost:7296/api/Usuarios')
      .subscribe({
        next: data => {
          this.usuariosDisponibles = data.map(u => ({
            id: u.cN_Id_usuario,
            nombre: u.cT_Nombre_usuario || u.ct_Nombre_usuario || u.email || 'Desconocido'
          }));
        },
        error: err => console.error('Error al cargar usuarios', err)
      });
  }

  // Cargar estados según el tipo de reporte seleccionado
  cargarEstados(): void {
    if (this.filtros.tipo === 'tareas') {
      this.http.get<any[]>('https://localhost:7296/api/Estados')
        .subscribe({
          next: data => {
            this.estadosDisponibles = data.map(e => ({
              id: e.cN_Id_estado,
              nombre: e.cT_Estado
            }));
          },
          error: err => console.error('Error al cargar estados de tareas', err)
        });
    } else {
      // Cargar manualmente para permisos (no hay endpoint)
      this.estadosDisponibles = [
        { id: 1, nombre: 'Registrado' },
        { id: 6, nombre: 'Aprobado' },
        { id: 7, nombre: 'Rechazado' }
      ];
    }
  }

  // Al cambiar tipo, recargar estados disponibles
  onTipoCambio(): void {
    this.filtros.estado = '';
    this.cargarEstados();
  }

  // Consultar reportes con filtros aplicados
  obtenerReportes(): void {
    const params = new HttpParams({ fromObject: this.limpiarVacios(this.filtros) });

    this.http.get<any[]>(`https://localhost:7296/api/Reportes`, { params })
      .subscribe({
        next: data => {
          this.reportes = data;
          this.yaConsultado = true;
        },
        error: err => {
          console.error('Error al obtener reportes', err);
          this.reportes = [];
          this.yaConsultado = true;
        }
      });
  }

  // Elimina filtros vacíos antes de enviar al backend
  limpiarVacios(obj: any): any {
    const limpio: any = {};
    for (const key in obj) {
      if (obj[key] !== '' && obj[key] !== null && obj[key] !== undefined) {
        limpio[key] = obj[key];
      }
    }
    return limpio;
  }
}
