import { Component, OnInit } from '@angular/core';
import { EstadisticasService } from '../services/estadisticas.service';
import { Router } from '@angular/router';  // Asegúrate de importar Router

@Component({
  selector: 'app-panel-estadisticas',
  templateUrl: './panel-estadisticas.component.html',
  standalone: false,
  styleUrls: ['./panel-estadisticas.component.scss']
})
export class PanelEstadisticasComponent implements OnInit {
  tarjetas: any[] = [];

  constructor(
    private estadisticasService: EstadisticasService,
    private router: Router  // Agregar el router aquí
  ) {}

  ngOnInit(): void {
    const rol = localStorage.getItem('rol');
    
    // Verificar si el rol es uno de los roles permitidos (1, 2, o 3)
    if (rol === '1' || rol === '2' || rol === '3') {
      this.obtenerEstadisticas();  // Solo obtener estadísticas si tiene el rol adecuado
    } else {
      this.router.navigate(['/tareas']);  // Redirigir al usuario si no tiene acceso
    }
  }

  obtenerEstadisticas(): void {
  this.estadisticasService.getEstadisticas().subscribe((data) => {
    console.log(data);
    // Verificar si data.tareasEnProceso es válido
    const tareasEnProceso = data.tareasEnProceso ? data.tareasEnProceso.cantidad : 0;
    const usuariosActivos = data.usuariosActivos ? data.usuariosActivos.numero : 0;  // Asumiendo que es un objeto con una propiedad 'numero'
    const permisosRegistradosCantidad = data.permisosRegistradosCantidad ? data.permisosRegistradosCantidad.cantidad : 0;
    const tareasProximasAVencerCantidad = data.tareasProximasAVencerCantidad ? data.tareasProximasAVencerCantidad.cantidad : 0;
    this.tarjetas = [
     { numero: data.usuariosActivos.usuariosActivos, descripcion: 'Usuarios Activos' },

      { numero: tareasEnProceso, descripcion: 'Tareas en Proceso' },  // Aquí garantizamos que siempre haya un valor numérico
       { numero: permisosRegistradosCantidad, descripcion: 'Permisos Solicitados' },  // Mostrar cantidad de permisos solicitados
      { numero: tareasProximasAVencerCantidad, descripcion: 'Tareas Próximas a Vencer' }  // Mostrar la cantidad de tareas próximas a vencer

    ];
  });
}

}
