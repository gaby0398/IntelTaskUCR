export interface IPermiso {
  cN_Id_permiso: number;
  cT_Titulo_permiso: string;
  cT_Descripcion_permiso: string;
  cN_Id_estado: number;
  cT_Descripcion_rechazo?: string;
  cF_Fecha_hora_registro: string;
  cF_Fecha_hora_inicio_permiso: string;
  cF_Fecha_hora_fin_permiso: string;
  cN_Usuario_creador: number;
}
