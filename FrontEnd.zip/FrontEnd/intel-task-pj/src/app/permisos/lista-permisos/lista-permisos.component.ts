import { Component, OnInit } from '@angular/core';
import { PermisoService } from '../permiso.service';
import { IPermiso } from '../permiso.model';
import { UsuarioService } from '../../services/usuario.service';


@Component({
  selector: 'app-lista-permisos',
  templateUrl: './lista-permisos.component.html',
  standalone: false,
  styleUrls: ['./lista-permisos.component.scss']
})
export class ListaPermisosComponent implements OnInit {
  permisos: IPermiso[] = [];
  usuarios: any[] = [];


  constructor(private permisoService: PermisoService,
  private usuarioService: UsuarioService) {}

 ngOnInit(): void {
  this.usuarioService.getAllUsuarios().subscribe((usuarios) => {
    this.usuarios = usuarios;

    this.permisoService.getPermisos().subscribe((data) => {
      this.permisos = data;
    });
  });
}

  getNombreEstado(idEstado: number): string {
  const estados: { [key: number]: string } = {
    1: 'Registrado',
    6: 'Aprobado',
    7: 'Rechazado'
    // podés agregar los demás
  };
  return estados[idEstado] || 'Desconocido';
  }

  getNombreUsuario(id: number): string {
  const usuario = this.usuarios.find(u => u.cN_Id_usuario === id);
  return usuario ? usuario.cT_Nombre_usuario : 'Desconocido';
  }



  ver(permiso: IPermiso) {
    console.log('Ver permiso', permiso);
  }

  aprobar(permiso: IPermiso) {
    console.log('Aprobar', permiso);
  }

  rechazar(permiso: IPermiso) {
    console.log('Rechazar', permiso);
  }
}
