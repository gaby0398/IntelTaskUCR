// permiso.service.ts
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPermiso } from './permiso.model';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PermisoService {
  private url = 'https://localhost:7296/api/Permiso';

  constructor(private http: HttpClient) {}

  getPermisos(): Observable<IPermiso[]> {
    return this.http.get<IPermiso[]>(this.url);
  }

  // endpoints para aprobar, rechazar, etc. se pueden agregar luego
}
