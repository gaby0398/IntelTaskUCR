import { NgModule, LOCALE_ID } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { AppComponent } from './app.component';
import { GestionTareasComponent } from './tareas/gestion-tareas/gestion-tareas.component';
import { CrearTareaComponent } from './tareas/crear-tarea/crear-tarea.component';
import { VerTareaComponent } from './tareas/ver-tarea/ver-tarea.component';
import { EditarTareaComponent } from './tareas/editar-tarea/editar-tarea.component';
import { CambiarEstadoComponent } from './tareas/cambiar-estado/cambiar-estado.component';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { TokenInterceptor } from './interceptors/token-interceptor';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { PanelEstadisticasComponent } from './panel-estadisticas/panel-estadisticas.component';
import { PanelUsuariosComponent } from './panel-usuarios/panel-usuarios.component';
import { MatTableModule } from '@angular/material/table'; 
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { NotificacionesComponent } from './notificaciones/notificaciones.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { ListaPermisosComponent } from './permisos/lista-permisos/lista-permisos.component';
import { ReportesComponent } from './reportes/reportes.component';
import { NgSelectModule } from '@ng-select/ng-select';
@NgModule({
  declarations: [
    AppComponent,
    GestionTareasComponent,
    CrearTareaComponent,
    VerTareaComponent,
    EditarTareaComponent,
    CambiarEstadoComponent,
    LoginComponent,
    RegisterComponent,
    NavbarComponent,
    SidebarComponent,
    PanelEstadisticasComponent,
    PanelUsuariosComponent,
    NotificacionesComponent,
    ListaPermisosComponent,
    ReportesComponent
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatDialogModule,
    MatSnackBarModule,
    NgSelectModule
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'es-CR' },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true // 👈 esto permite usar múltiples interceptores si más adelante agregás otro
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
