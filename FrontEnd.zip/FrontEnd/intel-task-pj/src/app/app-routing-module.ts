// src/app/app-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { GestionTareasComponent } from './tareas/gestion-tareas/gestion-tareas.component';
import { CrearTareaComponent } from './tareas/crear-tarea/crear-tarea.component';
import { RegisterComponent } from './auth/register/register.component';
import { PanelEstadisticasComponent } from './panel-estadisticas/panel-estadisticas.component';
import { AuthGuard } from './guards/auth-guard';
import { RoleGuard } from './guards/role-guard';
import { PanelUsuariosComponent } from './panel-usuarios/panel-usuarios.component';
import { NotificacionesComponent } from './notificaciones/notificaciones.component';
import { ListaPermisosComponent } from './permisos/lista-permisos/lista-permisos.component';
import { ReportesComponent } from './reportes/reportes.component';
const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'tareas', component: GestionTareasComponent },
  { path: 'tareas/nueva', component: CrearTareaComponent },
  { path: 'registro', component: RegisterComponent },
  { path: 'panel', component: PanelEstadisticasComponent, canActivate: [AuthGuard, RoleGuard] },  // Agregar ruta para el panel
  { path: 'usuarios', component: PanelUsuariosComponent },
  { path: 'notificaciones', component: NotificacionesComponent },
  { path: 'permisos', component: ListaPermisosComponent },
  { path: 'reportes', component: ReportesComponent }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
