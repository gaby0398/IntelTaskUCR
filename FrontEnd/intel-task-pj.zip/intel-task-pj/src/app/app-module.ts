import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { AppComponent } from './app.component';
import { GestionTareasComponent } from './tareas/gestion-tareas/gestion-tareas.component';
import { HttpClientModule } from '@angular/common/http';
import { LOCALE_ID } from '@angular/core';
import { CrearTareaComponent  } from './tareas/crear-tarea/crear-tarea.component';
import { FormsModule } from '@angular/forms';
import { VerTareaComponent } from './tareas/ver-tarea/ver-tarea.component';
import { CommonModule } from '@angular/common';


@NgModule({
  declarations: [
    AppComponent,
    GestionTareasComponent,
    CrearTareaComponent,
    VerTareaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'es-CR' },  
    provideBrowserGlobalErrorListeners()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
