import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CatalogoService {
  private baseUrl = 'https://localhost:7296/api';

  constructor(private http: HttpClient) {}

  getUsuarios(): Observable<{ id: number, nombre: string }[]> {
    return this.http.get<any[]>(`${this.baseUrl}/usuarios`).pipe(
      map(resp => resp
        .filter(u => u.cB_Estado_usuario)
        .map(u => ({
          id: u.cN_Id_usuario,
          nombre: u.cT_Nombre_usuario
        }))
      )
    );
  }

  getEstados(): Observable<{ id: number, nombre: string }[]> {
  return this.http.get<any[]>(`${this.baseUrl}/estados`).pipe(
    map(resp => resp.map(e => ({
      id: e.cN_Id_estado,
      nombre: e.cT_Estado
    })))
  );
}

getPrioridades(): Observable<{ id: number, nombre: string }[]> {
  return this.http.get<any[]>(`${this.baseUrl}/prioridades`).pipe(
    map(resp => resp.map(p => ({
      id: p.cN_Id_prioridad,
      nombre: p.cT_Nombre_prioridad
    })))
  );
}
/*
getComplejidades(): Observable<{ id: number, nombre: string }[]> {
  return this.http.get<{ id: number, nombre: string }[]>('https://localhost:7296/api/Complejidad');
}*/
getComplejidades(): Observable<any[]> {
  return this.http.get<any[]>('https://localhost:7296/api/Complejidad');
}



}
