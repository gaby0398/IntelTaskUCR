// src/app/tareas/tarea.model.ts
export interface ITarea {
  cN_Id_tarea: number;
  cN_Tarea_origen: number | null;
  cT_Titulo_tarea: string;
  cT_Descripcion_tarea: string;
  cT_Descripcion_espera?: string;
  cN_Id_complejidad: number;
  cN_Id_estado: number;
  cN_Id_prioridad: number;
  cN_Numero_GIS?: string;
  cF_Fecha_asignacion: string;
  cF_Fecha_limite: string;
  cF_Fecha_finalizacion?: string;
  cN_Usuario_creador: number;
  cN_Usuario_asignado?: number;
}
