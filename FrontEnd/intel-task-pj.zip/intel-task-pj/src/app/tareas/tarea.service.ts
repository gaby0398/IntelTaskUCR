// src/app/tareas/tarea.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ITarea } from './tarea.model';

@Injectable({
  providedIn: 'root'
})
@Injectable({ providedIn: 'root' })
export class TareaService {
  private baseUrl = 'https://localhost:7296/api/Tarea'; 
  private justificacionUrl = 'https://localhost:7296/api/TareaJustificacionRechazo';


  constructor(private http: HttpClient) { }

  getTareas(): Observable<ITarea[]> {
    return this.http.get<ITarea[]>(this.baseUrl);
  }

 crearTarea(tarea: any): Observable<any> {
  return this.http.post<any>(this.baseUrl, tarea);
  }
  getJustificacionesPorTarea(id: number): Observable<any[]> {
  return this.http.get<any[]>(`${this.justificacionUrl}/PorTarea/${id}`);
  }

  getHistorialEstadoPorTarea(tareaId: number): Observable<any[]> {
  return this.http.get<any[]>(`https://localhost:7296/api/BitacoraCambioEstado/PorTarea/${tareaId}`);
  }

  getAdjuntosPorTarea(idTarea: number): Observable<any[]> {
  return this.http.get<any[]>(`https://localhost:7296/api/Adjunto/tarea/${idTarea}`);
  }

  agregarAdjunto(adjunto: any): Observable<any> {
  return this.http.post<any>('https://localhost:7296/api/Adjunto', adjunto);
  }





}
