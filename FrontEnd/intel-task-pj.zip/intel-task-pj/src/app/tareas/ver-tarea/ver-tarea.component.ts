import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { ITarea } from '../tarea.model';
import { CatalogoService } from '../../catalogo/catalogo.service';
import { TareaService } from '../tarea.service';

@Component({
  selector: 'app-ver-tarea',
  standalone: false,
  templateUrl: './ver-tarea.component.html',
  styleUrls: ['./ver-tarea.component.scss']
})
export class VerTareaComponent implements OnInit {
  @Input() tarea!: ITarea;
  @Output() cerrar = new EventEmitter<void>();

  usuarios: { id: number, nombre: string }[] = [];
  estados: { id: number, nombre: string }[] = [];
  prioridades: { id: number, nombre: string }[] = [];
  justificaciones: any[] = [];
  historialEstado: any[] = [];
  adjuntos: any[] = [];

  // 👇 NUEVO para subir archivos
  nuevoArchivo: File | null = null;

  constructor(
    private catalogoService: CatalogoService,
    private tareaService: TareaService
  ) {}

  ngOnInit(): void {
    this.catalogoService.getUsuarios().subscribe(data => this.usuarios = data);
    this.catalogoService.getEstados().subscribe(data => this.estados = data);
    this.catalogoService.getPrioridades().subscribe(data => this.prioridades = data);

    this.tareaService.getJustificacionesPorTarea(this.tarea.cN_Id_tarea).subscribe(j => {
      this.justificaciones = j;

      this.tareaService.getHistorialEstadoPorTarea(this.tarea.cN_Id_tarea).subscribe(data => {
        this.historialEstado = data;
      });

      this.cargarAdjuntos();
    });
  }

  cerrarModal(): void {
    this.cerrar.emit();
  }

  getNombreUsuario(id?: number): string {
    if (!id) return '—';
    const usuario = this.usuarios.find(u => u.id === id);
    return usuario ? usuario.nombre : '—';
  }

  getNombreEstado(id: number): string {
    const estado = this.estados.find(e => e.id === id);
    return estado ? estado.nombre : 'Desconocido';
  }

  getNombrePrioridad(id: number): string {
    const prioridad = this.prioridades.find(p => p.id === id);
    return prioridad ? prioridad.nombre : 'Desconocido';
  }

  cargarAdjuntos(): void {
    if (this.tarea && this.tarea.cN_Id_tarea) {
      this.tareaService.getAdjuntosPorTarea(this.tarea.cN_Id_tarea).subscribe({
        next: (data) => {
          this.adjuntos = data;
        },
        error: (err) => {
          console.error('Error al obtener los adjuntos:', err);
        }
      });
    }
  }

  // 👇 NUEVO - manejador de archivo seleccionado
  onArchivoSeleccionado(event: any) {
    this.nuevoArchivo = event.target.files[0];
  }

  // 👇 NUEVO - lógica para enviar el archivo como adjunto
  subirAdjunto(): void {
    if (!this.nuevoArchivo || !this.tarea) return;

    const nuevoAdjunto = {
      cn_Documento: this.tarea.cN_Id_tarea,
      ct_Archivo_ruta: `archivos/${this.nuevoArchivo.name}`,
      cn_Usuario_accion: 1, // ⚠️ Reemplazar con el ID del usuario autenticado
      cf_Fecha_registro: new Date()
    };

    this.tareaService.agregarAdjunto(nuevoAdjunto).subscribe({
      next: () => {
        this.cargarAdjuntos(); // actualiza lista
        this.nuevoArchivo = null;
      },
      error: (err) => {
        console.error('Error al subir adjunto:', err);
      }
    });
  }
}
