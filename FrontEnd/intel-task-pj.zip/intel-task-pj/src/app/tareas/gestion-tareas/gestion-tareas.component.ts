// src/app/tareas/gestion-tareas/gestion-tareas.component.ts
import { Component, OnInit } from '@angular/core';
import { ITarea } from '../tarea.model';
import { TareaService } from '../tarea.service';
import { CatalogoService } from '../../catalogo/catalogo.service';


@Component({
  selector: 'app-gestion-tareas',
  standalone: false,
  templateUrl: './gestion-tareas.component.html',
  styleUrls: ['./gestion-tareas.component.scss']
})
export class GestionTareasComponent implements OnInit {
  tareas: ITarea[] = [];
  usuarios: { id: number, nombre: string }[] = [];
  estados: { id: number, nombre: string }[] = [];
  prioridades: { id: number, nombre: string }[] = [];
  tareaSeleccionada: ITarea | null = null;
  mostrarModalVer = false;

  

  displayedColumns = [
    'cT_Titulo_tarea',
    'cN_Usuario_asignado',
    'cN_Id_estado',
    'cN_Id_prioridad',
    'cF_Fecha_limite',
    'acciones'
  ];

  constructor(
    private tareaService: TareaService,
    private catalogoService: CatalogoService
  ) {}

  ngOnInit(): void {
    // Cargar catálogo de usuarios
    this.catalogoService.getUsuarios().subscribe(data => {
      this.usuarios = data;
    });

    this.catalogoService.getEstados().subscribe((data: { id: number, nombre: string }[]) => {
      this.estados = data;
    });

    this.catalogoService.getPrioridades().subscribe((data: { id: number, nombre: string }[]) => {
      this.prioridades = data;
    });


    // Cargar tareas
    this.tareaService.getTareas().subscribe({
      next: (data) => this.tareas = data,
      error: (err) => console.error('Error al cargar tareas', err)
    });
  }

  // Devuelve el nombre del usuario dado su ID
getNombreUsuario(id: number | undefined): string {
  return this.usuarios.find(u => u.id === id)?.nombre || 'Desconocido';
}

getNombreEstado(id: number | undefined): string {
  return this.estados.find(e => e.id === id)?.nombre || 'Sin estado';
}

getNombrePrioridad(id: number | undefined): string {
  return this.prioridades.find(p => p.id === id)?.nombre || 'Sin prioridad';
}

mostrarModalCrear: boolean = false;

abrirModal(): void {
  this.mostrarModalCrear = true;
}
cargarTareas(): void {
  this.tareaService.getTareas().subscribe((data) => {
    this.tareas = data;
  });
}

cerrarModal(): void {
  this.mostrarModalCrear = false;
   this.cargarTareas();
}

//tareaSeleccionada: ITarea | null = null;

abrirModalVer(tarea: ITarea): void {
  this.tareaSeleccionada = tarea;
}

abrirVerTarea(tarea: ITarea): void {
  this.tareaSeleccionada = tarea;
  this.mostrarModalVer = true;
}

cerrarModalVer(): void {
  this.mostrarModalVer = false;
  this.tareaSeleccionada = null;
}




}
