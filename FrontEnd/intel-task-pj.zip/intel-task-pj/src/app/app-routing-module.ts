// src/app/app-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GestionTareasComponent } from './tareas/gestion-tareas/gestion-tareas.component';
import { CrearTareaComponent } from './tareas/crear-tarea/crear-tarea.component';
const routes: Routes = [
  // Ruta por defecto redirige a /tareas
  { path: '', redirectTo: 'tareas', pathMatch: 'full' },
  // Ruta para la gestión de tareas
  { path: 'tareas', component: GestionTareasComponent },
  { path: 'tareas/nueva', component: CrearTareaComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
